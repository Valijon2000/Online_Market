from django.urls import path
from .views import Register, MyProfileView, MyProfileUpdateView, UserPasswordChangeView
from django.contrib.auth.views import LoginView, LogoutView

app_name = 'accounts'
urlpatterns = [
    path('register/', Register.as_view(), name='register'),
    path('login/', LoginView.as_view(), name='login'),
    path('logout/', LogoutView.as_view(), name='logout'),
    path('my_profile/', MyProfileView.as_view(), name='my_profile'),
    path('my_profile_update/<int:pk>/', MyProfileUpdateView.as_view(), name='my_profile_update'),
    # Password Change URLs
    path('user_password_change/', UserPasswordChangeView.as_view(), name='user_password_change'),

] 