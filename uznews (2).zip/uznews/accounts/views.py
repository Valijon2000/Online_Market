from django.shortcuts import render, redirect
from django.views.generic import ListView, DetailView, View
from .models import User
from .forms import RegisterForm, UserUpdateForm
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic.edit import UpdateView
from django.urls import reverse_lazy


# Create your views here.

class Register(View):
    def get(self, request, *args, **kwargs):

        context = {
            'form': RegisterForm()
        }

        return render(request, 'registration/register.html', context)
    
    def post(self, request, *args, **kwargs):
        form = RegisterForm(request.POST, request.FILES)

        if form.is_valid():
            form.save()

        context = {
            'form': form
        }


        return redirect('accounts:login')

class MyProfileView(LoginRequiredMixin, View):
    def get(self, request, *args, **kwargs):
        context = {
            'user': User.objects.get(id=request.user.id),
        }
        return render(request, 'user/my_profile.html', context)
    
class MyProfileUpdateView(LoginRequiredMixin, UpdateView):
    model = User
    form_class = UserUpdateForm
    template_name = 'user/user_update.html'
    success_url = reverse_lazy('accounts:my_profile')

    def test_func(self):
        news = self.get_object()
        if self.request.user == news.user or self.request.user.is_superuser:
            return True
        return False

    
from django.contrib.auth.views import PasswordChangeView

class UserPasswordChangeView(PasswordChangeView):
    template_name = 'user/user_password_change.html'  # Your custom password change template
    success_url = reverse_lazy('accounts:my_profile')  # Redirect URL after successful password change

