from django import forms
from .models import News

class AddNewsForm(forms.ModelForm):
    class Meta:
        model = News
        fields = ['title', 'description', 'body', 'img','video', 'category', 'tags', 'is_active']
        