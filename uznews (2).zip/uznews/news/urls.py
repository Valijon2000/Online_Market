from django.urls import path
from .views import HomePageView, AddNewsView, MyNewsView, NewsDetailView, NewsUpdateView, NewsDeleteView, SearchView
from .views import CategoryView
app_name = 'news'

urlpatterns = [
    path('', HomePageView.as_view(), name='home'),
    path('add_news/', AddNewsView.as_view(), name='add_news'),
    path('my_news/', MyNewsView.as_view(), name='my_news'),
    path('news_detail/<int:pk>/', NewsDetailView.as_view(), name='news_detail'),
    path('news_update/<int:pk>/', NewsUpdateView.as_view(), name='news_update'),
    path('news_delete/<int:pk>/', NewsDeleteView.as_view(), name='news_delete'), 
    path('search/', SearchView.as_view(), name='search'),
    path('category/<int:pk>/', CategoryView.as_view(), name='category'),
    
]

