from django.shortcuts import render
from django.views.generic import ListView, DetailView, View, CreateView
from .models import News, Category
from django.urls import reverse_lazy
from .forms import AddNewsForm
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.views.generic.edit import UpdateView, DeleteView
from django.db.models import Q

# Create your views here.

class HomePageView(View):
    def get(self, request, *args, **kwargs):

        context = {
            'news': News.objects.filter(is_active=True).order_by('-created_at'),
        }

        return render(request, 'home.html', context)
    

class SearchView(ListView):
    model = News
    template_name = 'search.html'

    def get_queryset(self):
        query = self.request.GET.get('search')
        object_list =News.objects.filter(Q(title__icontains=query) | Q(description__icontains=query) | Q(body__icontains=query) | Q(tags__name__icontains=query))
    
        return object_list
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['query'] = self.request.GET.get('search')
        return context

class AddNewsView(LoginRequiredMixin,CreateView):

    model = News
    form_class = AddNewsForm
    template_name = 'add_news.html'
    success_url = reverse_lazy('news:home')

    def form_valid(self, form):
        form.instance.user = self.request.user
        return super().form_valid(form)


class MyNewsView(LoginRequiredMixin,ListView):
    model = News
    template_name = 'my_news.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['my_news'] = News.objects.filter(user=self.request.user)

        return context

class NewsDetailView(View):
    def get(self, request, pk):
        
        context = {
            'news': News.objects.get(id=pk),
            'recommendations': News.objects.filter(category = News.objects.get(id=pk).category),
        }

        return render(request, 'news_detail.html', context)

class NewsUpdateView(LoginRequiredMixin,UserPassesTestMixin,UpdateView):
    model = News    
    form_class = AddNewsForm
    template_name = 'news_update.html'
    success_url = reverse_lazy('news:home')

    def test_func(self):
        news = self.get_object()
        if self.request.user == news.user or self.request.user.is_superuser:
            return True
        return False

class NewsDeleteView(LoginRequiredMixin,UserPassesTestMixin,DeleteView):
    model = News
    success_url = reverse_lazy('news:home')

    def test_func(self):
        news = self.get_object()
        if self.request.user == news.user or self.request.user.is_superuser:
            return True
        return False
    


class CategoryView(View):
    def get(self, request, pk):
        context = {
            'news': Category.objects.get(id=pk).news_category.all(),
        }

        return render(request, 'home.html', context)
    